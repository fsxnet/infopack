Hi Everyone!

As you may, or may not know, fsxNet now has an experimental FTN<>QWK gateway. The information contained in this archive, should give you all the information you need to connect to the QWK hub.

If you are not a member of fsxNet, why not? :) Just fill out the application with all of your information, and send it to Paul (Avon). Make sure you indicate either on the application, or in the email, that you would like to connect via QWK. This will tell Paul to forward the information to me, as I operate the QWK hub and Net 4 hub for fsxNet.

If you are a member of fsxNet, and would like to try out the QWK hub, feel free to contact me either in the echos, or via netmail at 21:1/186@fsxnet or 1:317/3@fidonet. I'll be able to get you set up and connected.

You will receive an email from me, usually within a few hours, but it can take up to a couple days. This is due to different time zone around the world, along with having to work, eat, sleep, etc. :)

Included in this archive are the following:

readme.txt   -=> You're reading it now! :)
fsxqwk.mys   -=> Instructions for setting up Mystic to connect via QWK
fsxqwk.syn   -=> Instructions for setting up Synchronet to connect via QWK
fsxqwk.lst   -=> Current list of message echos and conference numbers
file_id.diz  -=> Archive information
file_id.ans  -=> Fancy Archive information

If you have any questions/problems/concerns about setting up as a QWK node, feel free to email me at dan@castlerockbbs.com

If you have any questions about fsxNet in general, you can contact Paul (Avon) at avon@bbs.nz or myself, and we should be able to answer anything you throw at us. :)

Thank you for your interest in fsxNet. We're looking forward to getting you set up!

Black Panther(RCS)
aka Dan Richter
Sysop - Castle Rock BBS
telnet://bbs.castlerockbbs.com
http://www.castlerockbbs.com
The sparrows are flying again...


==========================================================

Thanks for your interest in fsxNet.

fsxNet is a fun, simple and experimental network.
Few message areas and file bases are used.
Setup is quick and easy. 

Please email me if you have questions
or need any help - avon@bbs.nz 

Credit to: RiPuk for his work on the fsxNet logo
and file_id.diz artwork used in the NET

==========================================================

This archive contains the following:

fsxnet.txt      - Info about fsxNet & application form
history.txt     - History of changes made to the fsxNet
systems.txt     - List of connected Bulletin Board Systems
news.txt        - Brief news highlights from fsxNet
netmail.txt     - An overview of netmail and routing
fsxnet.xxx      - Current nodelist (uncompressed)
fsxnet.zxx      - Current nodelist (compressed .zip format) 
fsxnet.na       - Message echolist         
fsx_file.na     - File echolist
fsxnet1.ans     - fsxNet Ansi Logo for your BBS
fsx-use.txt     - Setup Usenet Newsgroups
fsx-bre.txt     - Setup Barren Realms Elite (interbbs)
fsx-gd.txt      - Setup Galactic Dynasty (interbbs)
fsx-fh.txt      - Setup For Honour (interbbs)
fsxqwk.zip      - Setup info for access to fsxNet via QWK

==========================================================
# fsxNet Infopack

fsxNet is a fun, simple and experimental network established in late 2015.

The Infopack contains rego form, latest nodelist and more.
